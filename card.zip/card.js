const bodySelector = document.body;
const pages = document.querySelectorAll('.page'); 
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
const pageNumberEl = document.querySelector('.page-number');
const themeBtns = document.querySelectorAll('.theme-btn');
const textClassSelector=document.querySelectorAll('.text');
const cardWrapper = document.querySelector('.card-wrapper');
const card = document.querySelector('.card');
const btnz = document.querySelectorAll('.buttomofcard button'); 
let currentPage = 0;



  function myFunction() {
    themeBtns[0].click(); 
    themeBtns[1].click();
  }
  
  if (window.addEventListener) {
    window.addEventListener("load", myFunction, false);
  } else if (window.attachEvent) {
    window.attachEvent("onload", myFunction);
  } else {
    window.onload = myFunction;
  }




function showPage(index) {
  pages.forEach((page, i) => {
    page.classList.toggle('active', i === index);
  });
  pageNumberEl.textContent = `${index + 1}:${pages.length}`;
    
}

prevBtn.addEventListener('click', () => {
  currentPage = (currentPage - 1 + pages.length) % pages.length;
  showPage(currentPage);
});

nextBtn.addEventListener('click', () => {
  currentPage = (currentPage + 1) % pages.length;
  showPage(currentPage);
});

function textClassSelectorWeight(weight) { 
  textClassSelector.forEach(element => {
    element.style.fontWeight=weight;
  });
  
}
function textClassSelectorFamily(family) { 
  textClassSelector.forEach(element => {
    element.style.fontFamily=family;
  });
}
 

const fonts = [ 
  
  { name: 'NotoSans', style: 'NotoSans, sans-serif' },
  //{ name: 'Lato', style: 'Lato, sans-serif' },
  //{ name: 'MerriweatherSans', style: 'MerriweatherSans, serif' },
  { name: 'Montserrat', style: 'Montserrat, sans-serif' }, 
  { name: 'Courier New', style: 'Courier New, monospace' },
  { name: 'Poppins', style: 'Poppins, sans-serif' }, 
  //{ name: 'Roboto', style: 'Roboto, sans-serif' },
  //{ name: 'RobotoMono', style: 'RobotoMono, monospace' },
  { name: 'SourceCodePro', style: 'SourceCodePro, monospace' }
];

let currentFontIndex = 1; // Start from 1
const fontWeightList = [300,400,500,600,700,800,900,100,200];//['normal','bold','thin'];
let currentWeightIndex=1;
textClassSelectorFamily(fonts[currentFontIndex - 1].style); 
textClassSelectorWeight(fontWeightList[currentWeightIndex - 1]); 
document.getElementById('fontweight').innerText = fontWeightList[currentWeightIndex - 1]/100;
document.getElementById('fonttype').innerText=currentFontIndex;
document.getElementById('fonttype').onclick = function() {
    currentFontIndex = (currentFontIndex % fonts.length) + 1;  
    textClassSelectorFamily(fonts[currentFontIndex - 1].style); // Adjust for 0-based index
    this.innerText = currentFontIndex;
};

// Update font weight based on slider value
document.getElementById('fontweight').onclick = function() {
  currentWeightIndex = (currentWeightIndex % fontWeightList.length) + 1; 
  textClassSelectorWeight(fontWeightList[currentWeightIndex - 1]); // Adjust for 0-based index
  this.innerText = fontWeightList[currentWeightIndex - 1]/100;
 
};
let currentAngle = 0;
document.getElementById('rotatecard').onclick = function() {
  if(currentAngle===360){
    currentAngle=0;
  }
  currentAngle=currentAngle+90;
  cardWrapper.style.transform = 'rotate('+currentAngle+'deg)';
};
 


let isDarkMode1 = false;
let isDarkMode2 = false;
themeBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    const theme = btn.dataset.theme;
    if (theme === 'toggle-area2') {
      isDarkMode2 = !isDarkMode2;
      btn.textContent = isDarkMode2 ? '☀️' : '🌙';
      if (cardWrapper.classList.contains('dark-area2')) {
        cardWrapper.classList.remove('dark-area2', 'light-area2');
        cardWrapper.classList.add('light-area2');
        bodySelector.style.backgroundColor='#F5F5F5';
      } else {
        cardWrapper.classList.remove('dark-area2', 'light-area2');
        cardWrapper.classList.add('dark-area2'); 
        bodySelector.style.backgroundColor='#121212';
      } 
    } else if (theme === 'toggle-area1') {
      isDarkMode1 = !isDarkMode1;
      btn.textContent = isDarkMode1 ? '☀️' : '🌙' ;
      if (card.classList.contains('dark-area1')) {
        card.classList.remove('dark-area1', 'light-area1');
        card.classList.add('light-area1'); 
        btnz.forEach(button => {
          button.classList.remove('dark-area1', 'light-area1');
          button.classList.add('light-area1');
        });  
      } else {
        card.classList.remove('dark-area1', 'light-area1');
        card.classList.add('dark-area1');    
        btnz.forEach(button => {
          button.classList.remove('dark-area1', 'light-area1');
          button.classList.add('dark-area1');
        }); 
      }  
    }
  });
});

/*  // Check if the Web Speech API is supported
  if ('speechSynthesis' in window) {
    const speakButton = document.getElementById('readit'); 
    speakButton.addEventListener('click', () => {
      const utterance = new SpeechSynthesisUtterance(document.querySelector('.page.active').querySelector('.text').innerText);
      // Set the voice properties
      utterance.voice = speechSynthesis.getVoices().find(voice => voice.lang === 'en-US');
      utterance.rate = 1; // Speech rate (0.1 to 10)
      utterance.pitch = 1; // Speech pitch (0 to 2)
      speechSynthesis.speak(utterance);
    });
  } else {
    console.log('Web Speech API is not supported in this browser.');
  }
    //<button  id="readit">S</button>
*/

showPage(currentPage);
